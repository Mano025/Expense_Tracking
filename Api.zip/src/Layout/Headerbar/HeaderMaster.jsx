import React from 'react';
import './Header.css';
import Pic from '../../assets/images/pic.png'


const HeaderMaster = ({ username, profilePicUrl }) => {
  return (
    <div className="header-container">
      <h2 className="header-master">Master</h2>
      <div className="user-info">
      <span className="username">Username</span>
      <div className='imagess'>
        <img src={Pic} alt="Profile" className="profile-pic" style={{ height: '100px', width: '100px' }} />
        </div>
      </div>
    </div>
  );
};

export default HeaderMaster;