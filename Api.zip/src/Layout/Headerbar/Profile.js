import React from 'react';
import './Header.css';
import Pic from '../../assets/images/pic.png'


const HeaderMaster = ({ username, profilePicUrl }) => {
  return (
    <div className="header-container">
      
      <div className="user-info">
      <span className="username">Username</span>
        <img src={Pic} alt="Profile" className="profile-pic" />
       
      </div>
    </div>
  );
};

export default HeaderMaster;