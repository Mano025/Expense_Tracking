import React from "react";
import { Outlet } from "react-router-dom";
import Header from "./Headerbar/Header";

import "../components/style.css";
import Menu from "./SideMenu/Menu";

import { Grid, Paper } from "@mui/material";
import { TrackList, navList } from "./Headerbar/HeaderEntries";
import HeaderMaster from "./Headerbar/HeaderMaster";

const Main = ({ children }) => {
  return (
    // <div className="container">
    <Grid container md={12} lg={12} sm={12} xs={12} className="container"style={{ height: '100vh' }} >
      <Grid
        item
        md={2}
        lg={2}
        sm={12}
        xs={12}
        sx={{ backgroundColor: "lightgrey" }}
      >
        <Menu />
      </Grid>

      <Grid
        item
        md={10}
        lg={10}
        sm={12}
        xs={12}
        sx={{ backgroundColor: "#F5F5F5"  }}
      >
        <Grid>
          <HeaderMaster/>
        </Grid>
        <Grid container md={12} lg={12} sm={12} xs={12}>
          <Grid
            item
            md={12}
            lg={12}
            sm={12}
            xs={12}
           
          >
            <Header navList={navList} TrackList={TrackList} />
          </Grid>

          <Grid
            item
            md={12}
            lg={12}
            sm={12}
            xs={12}
            sx={{ backgroundColor: "white" }}
          >
            <Paper elevation={0}>{children || <Outlet />}</Paper>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
    // </div>
  );
};

export default Main;
