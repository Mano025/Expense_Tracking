import React from 'react'

import '../components/style.css'
import  {Pagination} from '@mui/material'

const PageNumber = () => {
  return (
    <div className="pagination-container">
    <span className="info">Page {1 + 1}, Out of {0}</span>
    <Pagination
      count={0}
      page={1}
      onChange={this.handleChangePage}
      shape="rounded"
      className="pagination"
    />
  </div>
  )
}

export default PageNumber