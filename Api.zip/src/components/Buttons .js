import React from 'react'
import { faPencilAlt, faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

export const Buttons = () => {
  return (
    <div>
        <button><FontAwesomeIcon icon={faPencilAlt} /></button>
        <button><FontAwesomeIcon icon={faTrash} /></button>
    </div>
  )
}