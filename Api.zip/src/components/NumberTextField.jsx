
// export default NumberTextField;
import React, { useState } from 'react';
import './NumberTextField.css'; // Import your CSS file

const NumberTextField = () => {
  // State to manage the selected country code and phone number
  const [selectedCountryCode, setSelectedCountryCode] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  // Handler function to update the selected country code
  const handleCountryCodeChange = (event) => {
    setSelectedCountryCode(event.target.value);
  };

  // Handler function to update the phone number
  const handlePhoneNumberChange = (event) => {
    setPhoneNumber(event.target.value);
  };

  // List of country codes (you can expand this list as needed)
  const countryCodes = [
    { code: '+1' },
    { code: '+91'},
    { code: '+44' },
    // Add more country codes here
  ];

  return (
    <div className="number-text-field">
      <label className="label">Phone Number</label>
      <div className="input-container">
        <select
          value={selectedCountryCode}
          onChange={handleCountryCodeChange}
          className="country-code"
        >
          <option value=""></option>
          {countryCodes.map((country) => (
            <option key={country.code} value={country.code}>
              {`(${country.code})`}
            </option>
          ))}
        </select>
        <input
          className="phone-number"
          type="text"
          value={phoneNumber}
          onChange={handlePhoneNumberChange}
          placeholder="Enter Phone Number"
        />
      </div>
    </div>
  );
};

export default NumberTextField;
