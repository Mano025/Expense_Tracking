export const MovieHeaders = [
  "S.no",
  "MovieName",
  "Staus",
  "CreatedDate",
  "Actions",
];

export const LocationHeaders = [
  "S.no",
  "Movie Name",
  "Location",
  "Created Date",
  "Actions",
];
export const CategoryHeaders = [
  "S.no",
  "Movie Name",
  "Category",
  "Created Date",
  "Actions",
];
export const SubCategoryHeaders = [
  "S.no",
  "Movie Name",
  "Category",
  "Sub Category",
  "Created Date",
  "Actions",
];
export const CrewHeaders = [
  "S.no",
  "Movie Name",
  "Location",
  "Category",
  "Sub Category",
  "Crew Name",
  "Gender",
  "Mobile Number",
  "Nationality",
  "Created Date",
  "Actions",
];

export const TableValues = [
  {
    "Sno": "1",
    "MovieName": "AAAA",
    "Staus": "completed",
    "CreatedDate": "10-05-2024",
    
  },
]