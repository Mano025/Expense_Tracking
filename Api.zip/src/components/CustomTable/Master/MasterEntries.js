export const MovieHeaders = [
    "S.no",
    "Movie Name",
    "Staus",
    "Created Date",
    "Actions",
  ];
  
  export const LocationHeaders = [
    "S.no",
    "Movie Name",
    "Location",
    "Mobile Number",
    "Created Date",
    "Actions",
  ];
  export const CategoryHeaders = [
    "S.no",
    "Movie Name",
    "Category",
    "Created Date",
    "Actions",
  ];
  export const SubCategoryHeaders = [
    "S.no",
    "Movie Name",
    "Category",
    "Subcategory",
    "Created Date",
    "Actions",
  ];
  export const CrewHeaders = [
    "S.no",
    "Movie Name",
    "Location",
    "Category",
    "Subcategory",
    "Crew Name",
    "Gender",
    "Mobile Number",
    "Nationality",
    "Created Date",
    "Actions",
  ];
  
  export const MovieValues = [
    {
      "Sno": "1",
      "MovieName": "AAAA",
      "Staus": "Active",
      "CreatedDate": "10-05-2024",
      
    },
    
  ];

  export const LocationValues = [
    {
      "Sno": "1",
      "MovieName": "AAAA",
      "Location":"Chennai",
      "MobileNumber":"123456789",
      "CreatedDate": "10-05-2024",
      
    },
   
  ];


  export const CategoryValues = [
    {
      "Sno": "1",
      "MovieName": "AAAA",
      "Cateogory": "aaabbbccc",
      "CreatedDate": "10-05-2024",
      
    },
    

  ];

  export const SubCategoryValues = [
    {
      "Sno": "1",
      "MovieName": "AAAA",
      "Cateogory": "aabbcc",
      "SubCategory": "aaabbbccc",
      "CreatedDate": "10-05-2024",
      
    },
   

  ];


  export const CrewValues = [
    {
      "Sno": "1",
      "MovieName": "AAAA",
      "Location":"Chennai",
    "Category":"aabbcc",
    "SubCategory":"aaabbbccc",
    "CrewName":"Bala",
    "Gender":"Male",
    "MobileNumber":"123456789",
    "Nationality":"Indian",
      
      "CreatedDate": "10-05-2024",
      
    },
    
    
  ];