export const ExpenseSheetHeaders = [
    "S.no",
    "Movie Name",
    "Location",
    "Date",
    "Crew Name",
    "Category",
    "Subcategory",
    "Number of Persons",
    "Advance",
    "Beta",
    "Actions",
  ];
  
 
 
  
  export const ExpenseSheetValues = [
    {
      "Sno": "1",
      "MovieName": "AAA",
      "Location":"Chennai",
      "date":"10-05-2024",
      "CrewName":"Bbcd",
      "Category":"aabbccdd",
      "SubCategory":"aaabbbccc",
      "NumberofPersons": "10",
      "Advance":"50000",
      "Beta":"1000",
      
    },
   
    
  ];