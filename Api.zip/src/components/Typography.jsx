import React from 'react';
import PropTypes from 'prop-types';
import { Typography } from '@mui/material';
// import colors from '../../utils/colors/index';

/**
 *
 * @param {object} props - required props
 * @returns {React.ReactElement} - returns the typography component
 */
function CustomTypography(props) {
  // const { type, text, customClass, colorType } = props;
  const { type, text, customClass, colon } = props;
  /**
   * @name getFontType
   * @returns {React.ReactElement}  - returns the required  font type of text
   */

  /**
   *@name getColorType
   *@returns {React.ReactElement}- returns the required type of text  colors
   */

  return (
    <Typography
      variant={type}
      // color={getColorType(colorType)}
      sx={{ fontFamily: 'Poppins_Medium' }}
      className={customClass}
    >
      {colon}
      {text}
    </Typography>
  );
}

export default CustomTypography;
CustomTypography.propTypes = {
  type: PropTypes.string.isRequired,
  text: PropTypes.string.isRequired,
  colon: PropTypes.string,
  customClass: PropTypes.string,
  // customStyle: PropTypes.oneOfType([PropTypes.object]),
};
CustomTypography.defaultProps = {
  colon: '',
  customClass: '',
  // customStyle: {},
};
