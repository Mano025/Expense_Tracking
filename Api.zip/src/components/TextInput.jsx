import React, { useEffect } from "react";
import { Grid, TextField, InputAdornment } from "@mui/material";
import PropTypes from "prop-types";
import CustomTypography from "./Typography";
import "./ComponentStyles.css";
/**
 *
 * @param {object} props - required props in TextInput component
 * @returns {React.ReactElement} - returns the TextInput component
 */
function TextInput(props) {
  const {
    label,
    isLogin,
    value,
    uniqueText,
    onHandleChange,
    multiline,
    rows,
    disabled,
    customClass,
    iconSource,
    textInputIcon,
    maxLength,
    requiredField,
    type,
    placeholder,
    defaultValue,
    resetValue,
  } = props;
  const [onChangeValue, setOnChangeValue] = React.useState(defaultValue);

  useEffect(() => {
    setOnChangeValue(defaultValue);
  }, [defaultValue]);

  useEffect(() => {
    setOnChangeValue("");
  }, [resetValue]);

  const handleChange = (e) => {
    let inputValue = e.target.value;
    if (type === "number" && inputValue.length > maxLength) {
      inputValue = inputValue.slice(0, maxLength);
    }

    onHandleChange(inputValue);
    setOnChangeValue(inputValue);
  };
  return (
    <Grid container md={12} lg={12} sm={12} xs={12}>
      <Grid item md={12} lg={12} sm={12} xs={12} className="inputWidth">
        <CustomTypography
          text={label}
          requiredField={requiredField && "required"}
          type="labels"
          customClass="textLabel"
        />
        {/* <TextField
          variant="outlined"
          size="small"
          fullWidth
          placeholder={placeholder}
          onChange={handleChange}
          value={onChangeValue}
          type={type}
          inputProps={{ maxLength: maxLength ,
            endAdornment: (
              <InputAdornment position="start">
                {textInputIcon && <img src={iconSource} alt="password" />}
              </InputAdornment>
            ),
          }}
          multiline={multiline}
          disabled={disabled}
          className={customClass}
          rows={rows}
          defaultValue={defaultValue}
          autoComplete="off"
        /> */}
        <TextField
          variant="outlined"
          size="small"
          fullWidth
          onChange={onHandleChange}
          value={value}
          type={type}
          multiline={multiline}
          disabled={disabled}
          className={`${isLogin && "loginBox"} ${customClass} ${
            disabled && "disable"
          }textBox`}
          id={uniqueText && "uppercase"}
          rows={rows}
          placeholder={placeholder}
          InputProps={{
            // style: { fontSize: 49 },
            maxLength: maxLength,
            endAdornment: (
              <InputAdornment className="loginImg" position="start">
                {textInputIcon && <img src={iconSource} alt="password" />}
              </InputAdornment>
            ),
          }}
        />
      </Grid>
    </Grid>
  );
}
export default TextInput;

TextInput.propTypes = {
  label: PropTypes.string,
  onHandleChange: PropTypes.func.isRequired,
  multiline: PropTypes.bool,
  type: PropTypes.string,
  rows: PropTypes.number,
  disabled: PropTypes.bool,
  iconSource: PropTypes.string,
  textInputIcon: PropTypes.bool,
  placeholder: PropTypes.string,
  customClass: PropTypes.string,
  defaultValue: PropTypes.string,
  resetValue: PropTypes.bool,
};
TextInput.defaultProps = {
  label: "",
  multiline: false,
  rows: 4,
  disabled: false,
  type: "",
  iconSource: "",
  textInputIcon: false,
  placeholder: "",
  customClass: "",
  defaultValue: "",
  resetValue: false,
};
