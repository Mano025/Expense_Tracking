
import React, { useState } from 'react';
import SearchIcon from '@mui/icons-material/Search';
import InputAdornment from '@mui/material/InputAdornment';
import TextField from '@mui/material/TextField';


const SearchBar = ({ onSearch }) => {
  // State to manage the search query
  const [searchQuery, setSearchQuery] = useState('');

  // Handler function to update the search query
  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
    // Pass the search query to the parent component if needed
    onSearch(event.target.value);
  };

  return (
    // <TextField 
    //   className='Movie'
    //   placeholder="Search..."
    //   value={searchQuery}
    //   onChange={handleSearchChange}
    //   InputProps={{
    //     startAdornment: (
    //       <InputAdornment position="start">
    //         <SearchIcon  />
    //       </InputAdornment>
    //     ),
    //   }}
    // />
    <TextField 
  className='SearchBar'
  placeholder="Search..."
  value={searchQuery}
  onChange={handleSearchChange}
  sx={{
    width: '150px', // Adjust the width as needed
    '& .MuiInputBase-input': {
      padding: '2px', // Adjust the padding of the input field as needed
     
    },
  }}
  InputProps={{
    startAdornment: (
      <InputAdornment position="start">
        <SearchIcon />
      </InputAdornment>
    ),
  }}
/>

  );
};

export default SearchBar;
