import { Box, Container, Grid } from '@mui/material';
import Button from '@mui/material/Button';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormLabel from '@mui/material/FormLabel';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import React, { useState } from 'react';
import NumberTextField from '../../../components/NumberTextField';
import SearchAppBar from '../../../components/SearchAppBar';
import Table from '../../../components/Table';
import '../category/Category.css';
import CusTable from '../../../components/CustomTable/CusTable';
import * as MASTER from '../../../components/CustomTable/Master/MasterEntries';


const Item = styled('div')(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    
    color: theme.palette.text.secondary,
  }));
const Crewpage = () => {
    const[CrewValue, setCrewValue]= useState('') 
    const[NationalityValue, setNationalityValue]= useState('') 
  const [selectedMovie, setSelectedMovie] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubCategory, setSelectedSubCategory] = useState('');

  const handleMovie = (event) => {
    setSelectedMovie(event.target.value);
  };

  const handleLocation = (event) => {
    setSelectedLocation(event.target.value);
  };

  const handleCategory = (event) => {
    setSelectedCategory(event.target.value);
  }
  const handleSubCategory = (event) => {
    setSelectedSubCategory(event.target.value);
  }
  return (
  
<>
<div >
 <Grid container spacing={2} >
   <Container>
     <Box display="flex" justifyContent="space-between" mt={4} >
       <Box
         
        
         bgcolor= "white"

         color="black"
         p={2}
         borderRadius={3}
         boxShadow={3}
       >

  <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 3, md: 3 }}>
    <Grid item xs={4}>
      <Item><div>
   <label>Movie Name</label>
    <select value={selectedMovie} onChange={handleMovie} className='Movie'>
    <option value="" disabled>Select Movie</option>  
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select>
</div></Item>
    </Grid>
    <Grid item xs={4}>
      <Item><label>Location</label>
    <select value={selectedLocation} onChange={handleLocation}className='Movie'>
    <option value="" disabled>Select Location</option>  
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select></Item>
    </Grid>
    <Grid item xs={4}>
      <Item><div>
    <label>category</label>
    <select value={selectedCategory} onChange={handleCategory}className='Movie'>
    <option value="" disabled>Select Category</option>  
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select>
  </div></Item>
    </Grid>
    <Grid item xs={4}>
      <Item><div>
    <label>Subcategory</label>
    <select value={selectedSubCategory} onChange={handleSubCategory}className='Movie'>
    <option value="" disabled>Select SubCategory</option>  
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
    </select>
  </div></Item>
    </Grid>
    <Grid item xs={4}>
      <Item>   
      <label>Crew Name</label>
        <input
        type="text"
        value={CrewValue}
        onChange={(e)=>(setCrewValue(e.target.value))}
        // variant="outlined"
        placeholder='Enter Category'
        className='Movie'></input>
     
   
</Item>
    </Grid>
    <Grid item xs={4}>
      <Item><div>
<FormControl>
  <FormLabel id="demo-row-radio-buttons-group-label">Gender</FormLabel>
  <RadioGroup 
    row
    aria-labelledby="demo-row-radio-buttons-group-label"
    name="row-radio-buttons-group"
  >
    <FormControlLabel value="female" control={<Radio />} label="Female" />
    <FormControlLabel value="male" control={<Radio />} label="Male" />
    <FormControlLabel value="other" control={<Radio />} label="Other" />
   
  </RadioGroup>
</FormControl>
</div></Item>
    </Grid>
    <Grid item xs={4}>
      <Item>
        <NumberTextField/>
      </Item>
    </Grid>
    <Grid item xs={4}>
      <Item><label>Nationality</label>
        <input
        type="text"
        value={NationalityValue}
        onChange={(e)=>(setNationalityValue(e.target.value))}
        // variant="outlined"
        placeholder='Enter Category'
        className='Movie'
        ></input></Item>
    </Grid>
    <Grid item xs={4}>
      <Item></Item>
    </Grid>
    
    <Grid item xs={9}>
      <Item></Item>
    </Grid>
    <Grid item xs={12} md={1.5} lg={1.5} sm={9}>
          <Item>
           <button className='submit'>submit</button>
          </Item>
        </Grid>
        <Grid item md={1.5} lg={1.5} sm={9} xs={12}>
          <Item>
           <button className='cancel'>cancel</button>
          </Item>
        </Grid>
  </Grid>
  </Box>

</Box>
</Container>
</Grid>

<Grid container>
<Container>
<Box


bgcolor="white"
color="black"
p={2}
borderRadius={3}
boxShadow={3}
mt={4}
>
    <div>
    <Grid container>
      <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.CrewHeaders}
                  Tabledata={MASTER.CrewValues}
                  TableTittle="Crew"
                />
              </Grid>
            </Grid>
        </div>
</Box>
</Container>
</Grid>

</div>
</>
  )
}

export default Crewpage;