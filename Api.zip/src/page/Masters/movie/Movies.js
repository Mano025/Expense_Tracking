import { Box, Container, Grid } from "@mui/material";
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormLabel from '@mui/material/FormLabel';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import { styled } from '@mui/material/styles';
import React, { useState } from 'react';
import './Movies.css';
import CusTable from '../../../components/CustomTable/CusTable';
import * as MASTER from '../../../components/CustomTable/Master/MasterEntries';

const Item = styled('div')(({ theme }) => ({
  color: theme.palette.secondary,
}));

const Movies = () => {
  const [selectedValue, setSelectedValue] = useState('');
  const handleChange = (e) => {
    setSelectedValue(e.target.value);
  };

  return (
    <div >
    <Grid container item md={12} lg={12} sm={12} xs={12} >
      <Container>
        <Box display="flex" justifyContent="space-between" mt={4}>
          <Box
            width="100%"
            
            bgcolor="white"
            color="black"
            p={3}
            borderRadius={3}
            boxShadow={3}
          >
          
  
  <Grid container md={12} lg={12} sm={12} xs={12} rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
      <Grid item xs={12} md={4} lg={4} sm={6}>
        <Item>
          <div className='firtdiv'>
              <label><h2>Movie Name</h2></label>
   
    <select value={selectedValue} onChange={handleChange} className='Moviename'>
    <option value="" disabled>Select Movie</option>
    <option value="option1">Option 1</option>
    <option value="option2">Option 2</option>
    <option value="option3">Option 3</option>
    <option value="option4">Option 4</option>
  </select>
{/* </Item>
</Grid> */}
  </div>
  </Item>
      </Grid>
      <Grid item xs={12} md={4} lg={4} sm={6}>
      <FormControl>
                    <FormLabel id="demo-row-radio-buttons-group-label">Status</FormLabel>
                    <RadioGroup
                      row
                      aria-labelledby="demo-row-radio-buttons-group-label"
                      name="row-radio-buttons-group"
                    >
                      <FormControlLabel value="Active" control={<Radio />} label="Active" />
                      <FormControlLabel value="Inactive" control={<Radio />} label="Inactive" />
                    </RadioGroup>
                  </FormControl>
      </Grid>
      
      <Grid item xs={12} md={9} lg={9} sm={10} >
        <Item>
       
        </Item>
      </Grid>
      <Grid item xs={12} md={1.5} lg={1.5} sm={6}>
        <Item>
         <button className='submit'>submit</button>
        </Item>
      </Grid>
      <Grid item xs={12} md={1.5} lg={1.5} sm={6}>
        <Item>
         <button className='cancel'>cancel</button>
        </Item>
      </Grid>
      
    </Grid>
            
          </Box>
        </Box>
      </Container>
    </Grid>
    <Grid container>
<Container>
<Box


bgcolor="white"
color="black"
p={2}
borderRadius={3}
boxShadow={3}
mt={4}
>
    <div>
    <Grid container>
      <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.MovieHeaders}
                  Tabledata={MASTER.MovieValues}
                  TableTittle="Movies"
                />
              </Grid>
            </Grid>
        </div>
</Box>
</Container>
</Grid>

    </div>
  );
}

export default Movies;