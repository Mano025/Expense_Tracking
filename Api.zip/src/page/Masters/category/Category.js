import React, { useState } from 'react';
import { Box, Container, Grid, TextField, MenuItem } from "@mui/material";
import './Category.css'
import { styled } from '@mui/material/styles';
// import Paper from '@mui/material/Paper';
// import CategoryTable from './CategoryTable';
// // import CategoryTable from '../Tables/CategoryTable';
import CusTable from '../../../components/CustomTable/CusTable';
import * as MASTER from '../../../components/CustomTable/Master/MasterEntries';


const Item = styled('div')(({ theme }) => ({
    // backgroundColor: "blue",
    ...theme.typography.body2,
   
    
    color: theme.palette.secondary,
  }));
const Category = () => {
    const [selectedValue, setSelectedValue] = useState('');
    const[categoryValue, setCategoryValue]= useState('')

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };
  return (
    <div >
      <Grid container item md={12} lg={12} sm={12} xs={12} >
        <Container>
          <Box display="flex" justifyContent="space-between" mt={4}>
            <Box
              width="95%"
              height={130}
              bgcolor="white"
              color="black"
              p={2}
              borderRadius={3}
              boxShadow={3}
            >
            
    
    <Grid container md={12} lg={12} sm={12} xs={12} rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
        <Grid item xs={12} md={4} lg={4} sm={6}>
          <Item>
            <div className='firtdiv'>
                <label>Movie Name</label>
     
      <select value={selectedValue} onChange={handleChange} className='Moviename'>
      <option value="" disabled>Select Movie</option>
      <option value="option1">Option 1</option>
      <option value="option2">Option 2</option>
      <option value="option3">Option 3</option>
      <option value="option4">Option 4</option>
    </select>
    </div>
    </Item>
        </Grid>
        <Grid item xs={12} md={3} lg={3} sm={6}>
          <Item><div secdiv>
        <label>Category</label>
        <input
        type="text"
        value={categoryValue}
        onChange={(e)=>(setCategoryValue(e.target.value))}
        // variant="outlined"
        placeholder='Enter Category'
        className='category'></input>
    </div></Item>
        </Grid>
        <Grid item xs={12} md={1} lg={1} sm={6}>
          <Item>
            <div>
            <button type="submit" className='adding'>+</button>
            </div>
          </Item>
        </Grid>
        <Grid item xs={12} md={9} lg={9} sm={10} >
          <Item>
           
          </Item>
        </Grid>
        <Grid item xs={12} md={1.5} lg={1.5} sm={6}>
          <Item>
           <button className='submit'>submit</button>
          </Item>
        </Grid>
        <Grid item xs={12} md={1.5} lg={1.5} sm={6}>
          <Item>
           <button className='cancel'>cancel</button>
          </Item>
        </Grid>
        
      </Grid>
              
            </Box>
          </Box>
        </Container>
      </Grid>

      <Grid container>
<Container>
<Box


bgcolor="white"
color="black"
p={2}
borderRadius={3}
boxShadow={3}
mt={4}
>
    <div>
    <Grid container>
      <Grid item xs={12}>
                <CusTable
                  TableHeading={MASTER.CategoryHeaders}
                  Tabledata={MASTER.CategoryValues}
                  TableTittle="Category"
                />
              </Grid>
            </Grid>
        </div>
</Box>
</Container>
</Grid>

    </div>
  );
};

export default Category;